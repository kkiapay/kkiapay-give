<?php 



class Kkiapay_Give_Settings {

  public function __construct()
  {


   
  }
  

}